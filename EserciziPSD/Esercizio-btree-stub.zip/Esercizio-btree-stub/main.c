#include <stdio.h>
#include <stdlib.h>
#include "item.h"
#include "list.h"
#include "btree.h"


int isANumber(char c);


int main(){
	
	
}


int isANumber(char c) {
	return (c == '1' || 
		c == '2' || 
		c == '3' || 
		c == '4' || 
		c == '5' || 
		c == '6' ||
		c == '7' ||
		c == '8' ||
		c == '9' ||
		c == '0' 		
		);


}

