#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main() { // non modificare/spostare questa riga
	srand(time(NULL)); // non modificare/spostare questa riga


}
