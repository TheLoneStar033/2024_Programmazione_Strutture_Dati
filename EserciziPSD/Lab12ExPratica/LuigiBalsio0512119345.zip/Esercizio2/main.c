#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "btree.h"

BTree newRandomTree(int maxh);


void Original(BTree tree){
  if(!isEmptyTree(tree)){
	
	if(getLeft(tree) && getRight(tree)){
		printf("(");
	}
	Original(getLeft(tree));
	outputItem(getBTreeRoot(tree));
    Original(getRight(tree));
	
	if(getLeft(tree) && getRight(tree)){
		printf(")");
	}
  }
}


int main(){
	srand(time(NULL)); // lasciare questa riga

	int n=4;
	BTree b=newRandomTree(n);
	printTree(b);
	Original(b);

	

}

BTree newRandomTree(int maxh) {
	if(maxh <= 0)
		return NULL;
	BTree left = NULL, right = NULL;
	if(rand() % 3) {
		left = newRandomTree(maxh - 1);
		right = newRandomTree(maxh - 1);
	}
	char *a = calloc(2, sizeof(char));
	char ops[] = {'+', '-', '*', '/'};
	a[0] = left ? ops[rand() % 4] : '0' + rand() % 10;
	return buildTree(left, right, a);
}
