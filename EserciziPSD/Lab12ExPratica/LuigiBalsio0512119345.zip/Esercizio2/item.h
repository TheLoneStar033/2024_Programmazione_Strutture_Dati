//1) creare un item.h
//con tutti i suoi prototipi

typedef void* Item;

Item inputItem();
void outputItem(Item);
int cmpItem(Item, Item);
char* itemToString(Item);
